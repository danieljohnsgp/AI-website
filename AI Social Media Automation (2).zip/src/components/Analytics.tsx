import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Heart, 
  MessageCircle, 
  Share2,
  Clock,
  Target,
  Lightbulb
} from "lucide-react";
import { analyticsData, platformStats } from "../lib/mockData";

export function Analytics() {
  const weeklyData = [
    { day: 'Mon', posts: 3, engagement: 450 },
    { day: 'Tue', posts: 2, engagement: 380 },
    { day: 'Wed', posts: 4, engagement: 620 },
    { day: 'Thu', posts: 3, engagement: 510 },
    { day: 'Fri', posts: 5, engagement: 890 },
    { day: 'Sat', posts: 2, engagement: 340 },
    { day: 'Sun', posts: 1, engagement: 210 }
  ];

  const topPosts = [
    {
      id: 1,
      platform: "TikTok",
      content: "POV: You just discovered AI automation for social media 🤯",
      likes: 1247,
      comments: 89,
      shares: 156,
      engagement: "12.5%"
    },
    {
      id: 2,
      platform: "Instagram",
      content: "Transform your social media strategy with AI! 🚀",
      likes: 892,
      comments: 45,
      shares: 78,
      engagement: "8.3%"
    },
    {
      id: 3,
      platform: "LinkedIn",
      content: "The future of marketing is here. AI-powered content that converts.",
      likes: 543,
      comments: 67,
      shares: 123,
      engagement: "6.7%"
    }
  ];

  const insights = [
    {
      type: "success",
      title: "Peak Performance Day",
      description: "Friday posts get 2.3x more engagement than average",
      icon: TrendingUp,
      color: "text-green-600"
    },
    {
      type: "warning",
      title: "Consistency Opportunity",
      description: "Weekend posting could improve overall reach by 15%",
      icon: Target,
      color: "text-yellow-600"
    },
    {
      type: "tip",
      title: "Content Mix",
      description: "Video content performs 3x better than static images",
      icon: Lightbulb,
      color: "text-blue-600"
    },
    {
      type: "success",
      title: "Hashtag Strategy",
      description: "Your hashtag usage is driving 40% more discoverability",
      icon: TrendingUp,
      color: "text-green-600"
    }
  ];

  const maxEngagement = Math.max(...weeklyData.map(d => d.engagement));

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1>Analytics & Insights 📊</h1>
        <p className="text-muted-foreground">Track your performance and discover optimization opportunities</p>
      </div>

      {/* KPI Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Time Saved</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{analyticsData.timeSavedPerWeek}</div>
            <p className="text-xs text-muted-foreground">per week</p>
            <div className="flex items-center gap-1 mt-2 text-green-600 text-xs">
              <TrendingUp className="w-3 h-3" />
              <span>40% improvement</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Consistency</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{analyticsData.consistencyRate}</div>
            <p className="text-xs text-muted-foreground">posting rate</p>
            <div className="flex items-center gap-1 mt-2 text-green-600 text-xs">
              <TrendingUp className="w-3 h-3" />
              <span>Above 90% target</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Engagement</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{analyticsData.engagementIncrease}</div>
            <p className="text-xs text-muted-foreground">vs last month</p>
            <div className="flex items-center gap-1 mt-2 text-green-600 text-xs">
              <TrendingUp className="w-3 h-3" />
              <span>Exceeds 20% goal</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Posts</CardTitle>
            <MessageCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{analyticsData.totalPosts}</div>
            <p className="text-xs text-muted-foreground">all platforms</p>
            <div className="flex items-center gap-1 mt-2 text-blue-600 text-xs">
              <TrendingUp className="w-3 h-3" />
              <span>{analyticsData.weeklyGrowth} this week</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Avg Reach</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">28.4K</div>
            <p className="text-xs text-muted-foreground">per post</p>
            <div className="flex items-center gap-1 mt-2 text-green-600 text-xs">
              <TrendingUp className="w-3 h-3" />
              <span>+12% growth</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Performance Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Weekly Performance</CardTitle>
          <CardDescription>Posts and engagement over the past 7 days</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-end justify-between gap-2 h-48">
              {weeklyData.map((data, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                  <div className="w-full flex flex-col items-center gap-1">
                    <div className="text-xs text-muted-foreground">{data.engagement}</div>
                    <div
                      className="w-full bg-blue-500 rounded-t hover:bg-blue-600 transition-colors cursor-pointer"
                      style={{ height: `${(data.engagement / maxEngagement) * 160}px` }}
                    ></div>
                  </div>
                  <div className="text-center">
                    <p className="text-xs">{data.day}</p>
                    <Badge variant="secondary" className="text-xs mt-1">{data.posts} posts</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Performing Posts */}
        <Card>
          <CardHeader>
            <CardTitle>Top Performing Posts 🏆</CardTitle>
            <CardDescription>Your best content this week</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topPosts.map((post, idx) => (
                <div key={post.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Badge>{post.platform}</Badge>
                      <span className="text-xs text-muted-foreground">#{idx + 1}</span>
                    </div>
                    <Badge variant="outline" className="text-green-600 border-green-600">
                      {post.engagement}
                    </Badge>
                  </div>
                  <p className="text-sm">{post.content}</p>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      <span>{post.likes}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MessageCircle className="w-3 h-3" />
                      <span>{post.comments}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Share2 className="w-3 h-3" />
                      <span>{post.shares}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* AI Insights */}
        <Card>
          <CardHeader>
            <CardTitle>AI Insights & Recommendations 💡</CardTitle>
            <CardDescription>Personalized tips to improve your strategy</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {insights.map((insight, idx) => (
                <div key={idx} className="flex gap-3 p-3 border rounded-lg">
                  <div className={`mt-0.5 ${insight.color}`}>
                    <insight.icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">{insight.title}</p>
                    <p className="text-xs text-muted-foreground mt-1">{insight.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Platform Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Platform Breakdown</CardTitle>
          <CardDescription>Performance comparison across all platforms</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="engagement" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="engagement">Engagement</TabsTrigger>
              <TabsTrigger value="followers">Followers</TabsTrigger>
              <TabsTrigger value="posts">Posts</TabsTrigger>
            </TabsList>
            
            <TabsContent value="engagement" className="space-y-4 mt-4">
              {Object.entries(platformStats).map(([platform, stats]) => (
                <div key={platform} className="flex items-center gap-4">
                  <span className="w-24 capitalize text-sm">{platform}</span>
                  <div className="flex-1 bg-muted rounded-full h-8 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-end pr-3 text-xs text-white"
                      style={{ width: `${parseFloat(stats.avgEngagement) * 15}%` }}
                    >
                      {stats.avgEngagement}
                    </div>
                  </div>
                </div>
              ))}
            </TabsContent>

            <TabsContent value="followers" className="space-y-4 mt-4">
              {Object.entries(platformStats).map(([platform, stats]) => (
                <div key={platform} className="flex items-center gap-4">
                  <span className="w-24 capitalize text-sm">{platform}</span>
                  <div className="flex-1 bg-muted rounded-full h-8 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-end pr-3 text-xs text-white"
                      style={{ width: `${(stats.followers / 12500) * 100}%` }}
                    >
                      {stats.followers.toLocaleString()}
                    </div>
                  </div>
                </div>
              ))}
            </TabsContent>

            <TabsContent value="posts" className="space-y-4 mt-4">
              {Object.entries(platformStats).map(([platform, stats]) => (
                <div key={platform} className="flex items-center gap-4">
                  <span className="w-24 capitalize text-sm">{platform}</span>
                  <div className="flex-1 bg-muted rounded-full h-8 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-orange-500 to-red-500 flex items-center justify-end pr-3 text-xs text-white"
                      style={{ width: `${(stats.postsThisWeek / 8) * 100}%` }}
                    >
                      {stats.postsThisWeek} posts
                    </div>
                  </div>
                </div>
              ))}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
