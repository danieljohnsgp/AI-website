import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { 
  Palette, 
  User, 
  Bell, 
  Shield, 
  Instagram, 
  Linkedin, 
  Twitter, 
  Check,
  X,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import type { PersonalizationSettings } from './PersonalizationOnboarding';

interface SettingsProps {
  currentSettings: PersonalizationSettings;
  connectedPlatforms: string[];
  onUpdateSettings: (settings: PersonalizationSettings) => void;
  onUpdatePlatforms: (platforms: string[]) => void;
}

export function Settings({ 
  currentSettings, 
  connectedPlatforms,
  onUpdateSettings,
  onUpdatePlatforms 
}: SettingsProps) {
  const [settings, setSettings] = useState(currentSettings);
  const [platforms, setPlatforms] = useState(connectedPlatforms);
  const [connectingPlatform, setConnectingPlatform] = useState<string | null>(null);
  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    postReminders: true,
    performanceReports: true,
    trendingAlerts: false
  });

  const accentColors = [
    { id: 'blue', name: 'Blue', gradient: 'from-blue-500 to-blue-600' },
    { id: 'purple', name: 'Purple', gradient: 'from-purple-500 to-purple-600' },
    { id: 'pink', name: 'Pink', gradient: 'from-pink-500 to-pink-600' },
    { id: 'green', name: 'Green', gradient: 'from-green-500 to-green-600' },
    { id: 'orange', name: 'Orange', gradient: 'from-orange-500 to-orange-600' },
    { id: 'red', name: 'Red', gradient: 'from-red-500 to-red-600' }
  ];

  const themes = [
    { id: 'light', name: 'Light', preview: 'bg-white border-2' },
    { id: 'dark', name: 'Dark', preview: 'bg-gray-900 border-2' },
    { id: 'auto', name: 'Auto', preview: 'bg-gradient-to-r from-white to-gray-900 border-2' }
  ];

  const industries = [
    'SaaS/Technology',
    'E-commerce/Retail',
    'Marketing Agency',
    'Healthcare',
    'Education',
    'Finance',
    'Real Estate',
    'Entertainment',
    'Food & Beverage',
    'Other'
  ];

  const socialPlatforms = [
    { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'text-pink-600' },
    { id: 'tiktok', name: 'TikTok', icon: Twitter, color: 'text-black dark:text-white' },
    { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: 'text-blue-600' },
    { id: 'twitter', name: 'X (Twitter)', icon: Twitter, color: 'text-blue-400' }
  ];

  const handleSaveAppearance = () => {
    onUpdateSettings(settings);
    toast.success('Appearance settings saved!');
  };

  const handleSaveProfile = () => {
    onUpdateSettings(settings);
    toast.success('Profile settings saved!');
  };

  const handleConnectPlatform = async (platformId: string) => {
    setConnectingPlatform(platformId);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const newPlatforms = [...platforms, platformId];
    setPlatforms(newPlatforms);
    onUpdatePlatforms(newPlatforms);
    setConnectingPlatform(null);
    
    const platform = socialPlatforms.find(p => p.id === platformId);
    toast.success(`${platform?.name} connected successfully!`);
  };

  const handleDisconnectPlatform = (platformId: string) => {
    const newPlatforms = platforms.filter(id => id !== platformId);
    setPlatforms(newPlatforms);
    onUpdatePlatforms(newPlatforms);
    
    const platform = socialPlatforms.find(p => p.id === platformId);
    toast.info(`${platform?.name} disconnected`);
  };

  const handleSaveNotifications = () => {
    toast.success('Notification settings saved!');
  };

  const selectedColor = accentColors.find(c => c.id === settings.accentColor);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1>Settings ⚙️</h1>
        <p className="text-muted-foreground">Manage your account and application preferences</p>
      </div>

      <Tabs defaultValue="appearance" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="appearance" className="gap-2">
            <Palette className="w-4 h-4" />
            Appearance
          </TabsTrigger>
          <TabsTrigger value="profile" className="gap-2">
            <User className="w-4 h-4" />
            Profile
          </TabsTrigger>
          <TabsTrigger value="platforms" className="gap-2">
            <Instagram className="w-4 h-4" />
            Platforms
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-2">
            <Bell className="w-4 h-4" />
            Notifications
          </TabsTrigger>
        </TabsList>

        {/* Appearance Tab */}
        <TabsContent value="appearance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Theme Preferences</CardTitle>
              <CardDescription>Customize how SparkSocial looks to you</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label className="text-base">Theme Mode</Label>
                <RadioGroup
                  value={settings.theme}
                  onValueChange={(value) => setSettings({ ...settings, theme: value })}
                >
                  <div className="grid grid-cols-3 gap-4">
                    {themes.map((theme) => (
                      <div key={theme.id}>
                        <RadioGroupItem
                          value={theme.id}
                          id={`theme-${theme.id}`}
                          className="peer sr-only"
                        />
                        <Label
                          htmlFor={`theme-${theme.id}`}
                          className="flex flex-col items-center justify-between rounded-lg border-2 border-muted bg-transparent p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary cursor-pointer"
                        >
                          <div className={`w-16 h-16 rounded-lg ${theme.preview} mb-2`}></div>
                          <span>{theme.name}</span>
                          {settings.theme === theme.id && (
                            <Check className="w-4 h-4 text-primary mt-1" />
                          )}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator />

              <div className="space-y-3">
                <Label className="text-base">Accent Color</Label>
                <div className="grid grid-cols-6 gap-3">
                  {accentColors.map((color) => (
                    <button
                      key={color.id}
                      onClick={() => setSettings({ ...settings, accentColor: color.id })}
                      className={`relative w-full aspect-square rounded-lg bg-gradient-to-br ${color.gradient} hover:scale-110 transition-transform ${
                        settings.accentColor === color.id ? 'ring-4 ring-offset-2 ring-gray-400' : ''
                      }`}
                      title={color.name}
                    >
                      {settings.accentColor === color.id && (
                        <Check className="w-5 h-5 text-white absolute inset-0 m-auto" />
                      )}
                    </button>
                  ))}
                </div>
                <p className="text-sm text-muted-foreground">
                  Selected: {selectedColor?.name}
                </p>
              </div>

              <Separator />

              <div className="p-4 bg-muted rounded-lg border">
                <p className="text-sm mb-3">Preview:</p>
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${selectedColor?.gradient} flex items-center justify-center text-white`}>
                    SS
                  </div>
                  <div>
                    <p>SparkSocial Dashboard</p>
                    <p className="text-sm text-muted-foreground">
                      {settings.theme === 'auto' ? 'System theme' : `${settings.theme} mode`} • {selectedColor?.name} accent
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={handleSaveAppearance}>Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Profile Tab */}
        <TabsContent value="profile" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Brand Profile</CardTitle>
              <CardDescription>Update your brand information and preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="settings-brandName">Brand Name</Label>
                <Input
                  id="settings-brandName"
                  value={settings.brandName}
                  onChange={(e) => setSettings({ ...settings, brandName: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="settings-industry">Industry</Label>
                  <Select
                    value={settings.industry}
                    onValueChange={(value) => setSettings({ ...settings, industry: value })}
                  >
                    <SelectTrigger id="settings-industry">
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      {industries.map((industry) => (
                        <SelectItem key={industry} value={industry}>
                          {industry}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="settings-brandTone">Brand Tone</Label>
                  <Select
                    value={settings.brandTone}
                    onValueChange={(value) => setSettings({ ...settings, brandTone: value })}
                  >
                    <SelectTrigger id="settings-brandTone">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="friendly">Friendly 😊</SelectItem>
                      <SelectItem value="professional">Professional 💼</SelectItem>
                      <SelectItem value="casual">Casual 👋</SelectItem>
                      <SelectItem value="formal">Formal 🎩</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="settings-goals">Business Goals</Label>
                <Textarea
                  id="settings-goals"
                  value={settings.goals}
                  onChange={(e) => setSettings({ ...settings, goals: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="flex justify-end pt-4">
                <Button onClick={handleSaveProfile}>Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Platforms Tab */}
        <TabsContent value="platforms" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Connected Platforms</CardTitle>
              <CardDescription>Manage your social media connections</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {socialPlatforms.map((platform) => {
                  const Icon = platform.icon;
                  const isConnected = platforms.includes(platform.id);
                  const isConnecting = connectingPlatform === platform.id;

                  return (
                    <div
                      key={platform.id}
                      className={`flex items-center justify-between p-4 border rounded-lg ${
                        isConnected ? 'bg-green-50 dark:bg-green-950/20 border-green-500' : ''
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className={`w-6 h-6 ${platform.color}`} />
                        <div>
                          <p>{platform.name}</p>
                          {isConnected && (
                            <p className="text-xs text-muted-foreground">Connected</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {isConnected ? (
                          <>
                            <Badge className="bg-green-500">
                              <Check className="w-3 h-3 mr-1" />
                              Active
                            </Badge>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDisconnectPlatform(platform.id)}
                            >
                              <X className="w-4 h-4 mr-1" />
                              Disconnect
                            </Button>
                          </>
                        ) : (
                          <Button
                            size="sm"
                            onClick={() => handleConnectPlatform(platform.id)}
                            disabled={isConnecting}
                          >
                            {isConnecting ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                                Connecting...
                              </>
                            ) : (
                              'Connect'
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Choose what updates you want to receive</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive email updates about your account
                  </p>
                </div>
                <Switch
                  checked={notifications.emailNotifications}
                  onCheckedChange={(checked) =>
                    setNotifications({ ...notifications, emailNotifications: checked })
                  }
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Post Reminders</Label>
                  <p className="text-sm text-muted-foreground">
                    Get reminders for scheduled posts
                  </p>
                </div>
                <Switch
                  checked={notifications.postReminders}
                  onCheckedChange={(checked) =>
                    setNotifications({ ...notifications, postReminders: checked })
                  }
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Performance Reports</Label>
                  <p className="text-sm text-muted-foreground">
                    Weekly analytics and insights
                  </p>
                </div>
                <Switch
                  checked={notifications.performanceReports}
                  onCheckedChange={(checked) =>
                    setNotifications({ ...notifications, performanceReports: checked })
                  }
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Trending Alerts</Label>
                  <p className="text-sm text-muted-foreground">
                    Notifications about trending topics
                  </p>
                </div>
                <Switch
                  checked={notifications.trendingAlerts}
                  onCheckedChange={(checked) =>
                    setNotifications({ ...notifications, trendingAlerts: checked })
                  }
                />
              </div>

              <div className="flex justify-end pt-4">
                <Button onClick={handleSaveNotifications}>Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
