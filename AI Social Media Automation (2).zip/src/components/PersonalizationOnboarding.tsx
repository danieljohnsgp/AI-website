import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ArrowRight, Palette, Check } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface PersonalizationOnboardingProps {
  onComplete: (settings: PersonalizationSettings) => void;
}

export interface PersonalizationSettings {
  theme: string;
  accentColor: string;
  brandName: string;
  brandTone: string;
  industry: string;
  goals: string;
}

export function PersonalizationOnboarding({ onComplete }: PersonalizationOnboardingProps) {
  const [settings, setSettings] = useState<PersonalizationSettings>({
    theme: 'light',
    accentColor: 'blue',
    brandName: '',
    brandTone: 'friendly',
    industry: '',
    goals: ''
  });

  const themes = [
    { id: 'light', name: 'Light', preview: 'bg-white border-2' },
    { id: 'dark', name: 'Dark', preview: 'bg-gray-900 border-2' },
    { id: 'auto', name: 'Auto', preview: 'bg-gradient-to-r from-white to-gray-900 border-2' }
  ];

  const accentColors = [
    { id: 'blue', name: 'Blue', color: 'bg-blue-500', gradient: 'from-blue-500 to-blue-600' },
    { id: 'purple', name: 'Purple', color: 'bg-purple-500', gradient: 'from-purple-500 to-purple-600' },
    { id: 'pink', name: 'Pink', color: 'bg-pink-500', gradient: 'from-pink-500 to-pink-600' },
    { id: 'green', name: 'Green', color: 'bg-green-500', gradient: 'from-green-500 to-green-600' },
    { id: 'orange', name: 'Orange', color: 'bg-orange-500', gradient: 'from-orange-500 to-orange-600' },
    { id: 'red', name: 'Red', color: 'bg-red-500', gradient: 'from-red-500 to-red-600' }
  ];

  const industries = [
    'SaaS/Technology',
    'E-commerce/Retail',
    'Marketing Agency',
    'Healthcare',
    'Education',
    'Finance',
    'Real Estate',
    'Entertainment',
    'Food & Beverage',
    'Other'
  ];

  const handleComplete = () => {
    if (!settings.brandName.trim()) {
      toast.error('Please enter your brand name');
      return;
    }
    
    toast.success('Personalization saved!');
    onComplete(settings);
  };

  const selectedAccentColor = accentColors.find(c => c.id === settings.accentColor);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4">
      <div className="w-full max-w-3xl">
        <Card className="shadow-2xl">
          <CardHeader className="text-center space-y-2 pb-6">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Palette className="w-10 h-10 text-purple-600" />
            </div>
            <CardTitle className="text-3xl">Personalize Your Experience</CardTitle>
            <CardDescription className="text-base">
              Customize SparkSocial to match your brand and preferences
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-8">
            {/* Theme Selection */}
            <div className="space-y-3">
              <Label className="text-base">Choose Your Theme</Label>
              <RadioGroup
                value={settings.theme}
                onValueChange={(value) => setSettings({ ...settings, theme: value })}
              >
                <div className="grid grid-cols-3 gap-4">
                  {themes.map((theme) => (
                    <div key={theme.id}>
                      <RadioGroupItem
                        value={theme.id}
                        id={theme.id}
                        className="peer sr-only"
                      />
                      <Label
                        htmlFor={theme.id}
                        className="flex flex-col items-center justify-between rounded-lg border-2 border-muted bg-transparent p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary cursor-pointer"
                      >
                        <div className={`w-16 h-16 rounded-lg ${theme.preview} mb-2`}></div>
                        <span>{theme.name}</span>
                        {settings.theme === theme.id && (
                          <Check className="w-4 h-4 text-primary mt-1" />
                        )}
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>

            {/* Accent Color */}
            <div className="space-y-3">
              <Label className="text-base">Select Accent Color</Label>
              <div className="grid grid-cols-6 gap-3">
                {accentColors.map((color) => (
                  <button
                    key={color.id}
                    onClick={() => setSettings({ ...settings, accentColor: color.id })}
                    className={`relative w-full aspect-square rounded-lg bg-gradient-to-br ${color.gradient} hover:scale-110 transition-transform ${
                      settings.accentColor === color.id ? 'ring-4 ring-offset-2 ring-gray-400' : ''
                    }`}
                    title={color.name}
                  >
                    {settings.accentColor === color.id && (
                      <Check className="w-5 h-5 text-white absolute inset-0 m-auto" />
                    )}
                  </button>
                ))}
              </div>
              <p className="text-sm text-muted-foreground">
                Selected: {selectedAccentColor?.name}
              </p>
            </div>

            {/* Brand Details */}
            <div className="space-y-4 pt-4 border-t">
              <div className="space-y-2">
                <Label htmlFor="brandName">Brand Name *</Label>
                <Input
                  id="brandName"
                  placeholder="e.g., Acme Marketing"
                  value={settings.brandName}
                  onChange={(e) => setSettings({ ...settings, brandName: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="industry">Industry</Label>
                  <Select
                    value={settings.industry}
                    onValueChange={(value) => setSettings({ ...settings, industry: value })}
                  >
                    <SelectTrigger id="industry">
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      {industries.map((industry) => (
                        <SelectItem key={industry} value={industry}>
                          {industry}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="brandTone">Brand Tone</Label>
                  <Select
                    value={settings.brandTone}
                    onValueChange={(value) => setSettings({ ...settings, brandTone: value })}
                  >
                    <SelectTrigger id="brandTone">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="friendly">Friendly 😊</SelectItem>
                      <SelectItem value="professional">Professional 💼</SelectItem>
                      <SelectItem value="casual">Casual 👋</SelectItem>
                      <SelectItem value="formal">Formal 🎩</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="goals">What are your goals? (Optional)</Label>
                <Textarea
                  id="goals"
                  placeholder="e.g., Increase engagement by 50%, grow followers, drive website traffic..."
                  value={settings.goals}
                  onChange={(e) => setSettings({ ...settings, goals: e.target.value })}
                  rows={3}
                />
              </div>
            </div>

            {/* Preview Section */}
            <div className="p-4 bg-muted rounded-lg border">
              <p className="text-sm mb-3">Preview:</p>
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${selectedAccentColor?.gradient} flex items-center justify-center text-white`}>
                  {settings.brandName ? settings.brandName.substring(0, 2).toUpperCase() : 'BR'}
                </div>
                <div>
                  <p>{settings.brandName || 'Your Brand Name'}</p>
                  <p className="text-sm text-muted-foreground">
                    {settings.industry || 'Industry'} • {settings.brandTone} tone
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t">
              <Button 
                onClick={handleComplete}
                size="lg"
                className="gap-2"
              >
                Complete Setup
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
