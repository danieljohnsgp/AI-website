import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Loader2, Sparkles, Copy, RefreshCw, Eye } from "lucide-react";
import { generateContent, formatForPlatforms, type GenerateResponse, type FormatResponse } from "../lib/mockApi";
import { toast } from "sonner@2.0.3";

interface AICoCreatorProps {
  onNavigate: (view: string, data?: any) => void;
}

export function AICoCreator({ onNavigate }: AICoCreatorProps) {
  const [prompt, setPrompt] = useState("");
  const [brandTone, setBrandTone] = useState<'friendly' | 'professional' | 'casual' | 'formal'>('friendly');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<GenerateResponse | null>(null);
  const [formatted, setFormatted] = useState<FormatResponse | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error("Please enter a prompt");
      return;
    }

    setLoading(true);
    try {
      const result = await generateContent({ prompt, brandTone });
      setResponse(result);
      toast.success("Content generated successfully!");
    } catch (error) {
      toast.error("Failed to generate content");
    } finally {
      setLoading(false);
    }
  };

  const handleFormatForPlatforms = async () => {
    if (!response) return;

    setLoading(true);
    try {
      const result = await formatForPlatforms({
        caption: response.caption,
        hashtags: response.hashtags
      });
      setFormatted(result);
      toast.success("Content formatted for all platforms!");
    } catch (error) {
      toast.error("Failed to format content");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
  };

  const handlePreview = () => {
    if (formatted) {
      onNavigate('preview', { formatted });
    }
  };

  const handleRegenerate = () => {
    setResponse(null);
    setFormatted(null);
  };

  const examplePrompts = [
    "Share a productivity tip for social media managers",
    "Announce our new AI features for content automation",
    "Share a customer success story",
    "Create a post about time-saving marketing hacks"
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1>AI Co-Creator ✨</h1>
        <p className="text-muted-foreground">Let AI help you brainstorm and create engaging content</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Create Content</CardTitle>
              <CardDescription>Describe what you want to post about</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm">Brand Tone</label>
                <Select value={brandTone} onValueChange={(v: any) => setBrandTone(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="friendly">Friendly 😊</SelectItem>
                    <SelectItem value="professional">Professional 💼</SelectItem>
                    <SelectItem value="casual">Casual 👋</SelectItem>
                    <SelectItem value="formal">Formal 🎩</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm">Your Prompt</label>
                <Textarea
                  placeholder="e.g., Share tips about using AI for social media marketing..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={5}
                />
              </div>

              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Example prompts:</p>
                <div className="flex flex-wrap gap-2">
                  {examplePrompts.map((example, idx) => (
                    <Badge
                      key={idx}
                      variant="outline"
                      className="cursor-pointer hover:bg-accent"
                      onClick={() => setPrompt(example)}
                    >
                      {example}
                    </Badge>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={loading || !prompt.trim()}
                className="w-full gap-2"
                size="lg"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Generate Content
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Output Section */}
        <div className="space-y-4">
          {response ? (
            <>
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Generated Content</CardTitle>
                    <Badge>{response.contentTone}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm">Caption</label>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="text-sm whitespace-pre-wrap">{response.caption}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm">Hashtags</label>
                    <div className="flex flex-wrap gap-2">
                      {response.hashtags.map((tag, idx) => (
                        <Badge key={idx} variant="secondary">{tag}</Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1 gap-2"
                      onClick={() => handleCopy(response.caption)}
                    >
                      <Copy className="w-4 h-4" />
                      Copy
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1 gap-2"
                      onClick={handleRegenerate}
                    >
                      <RefreshCw className="w-4 h-4" />
                      Regenerate
                    </Button>
                  </div>

                  <Button
                    onClick={handleFormatForPlatforms}
                    disabled={loading}
                    className="w-full gap-2"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Formatting...
                      </>
                    ) : (
                      <>
                        Format for All Platforms
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {formatted && (
                <Card>
                  <CardHeader>
                    <CardTitle>Platform Previews</CardTitle>
                    <CardDescription>Content optimized for each platform</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm">Instagram</label>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopy(formatted.instagram)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                      <div className="p-2 bg-muted rounded text-xs whitespace-pre-wrap">
                        {formatted.instagram}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm">TikTok</label>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopy(formatted.tiktok)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                      <div className="p-2 bg-muted rounded text-xs whitespace-pre-wrap">
                        {formatted.tiktok}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm">LinkedIn</label>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopy(formatted.linkedin)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                      <div className="p-2 bg-muted rounded text-xs whitespace-pre-wrap">
                        {formatted.linkedin}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm">X (Twitter)</label>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopy(formatted.twitter)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                      <div className="p-2 bg-muted rounded text-xs whitespace-pre-wrap">
                        {formatted.twitter}
                      </div>
                    </div>

                    <Button
                      onClick={handlePreview}
                      variant="outline"
                      className="w-full gap-2"
                    >
                      <Eye className="w-4 h-4" />
                      View Full Preview
                    </Button>
                  </CardContent>
                </Card>
              )}
            </>
          ) : (
            <Card className="h-full flex items-center justify-center">
              <CardContent className="text-center py-12">
                <Sparkles className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">
                  Enter a prompt and click Generate to create content
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
