import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Calendar } from "./ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Instagram, Linkedin, Twitter, Clock, Sparkles, CalendarIcon } from "lucide-react";
import { getOptimalSchedule } from "../lib/mockApi";
import { toast } from "sonner@2.0.3";

interface ScheduledPost {
  id: string;
  platform: string;
  content: string;
  time: string;
  confidence: number;
}

export function Scheduler() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [selectedPlatform, setSelectedPlatform] = useState("all");
  const [recommendation, setRecommendation] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const scheduledPosts: ScheduledPost[] = [
    {
      id: "1",
      platform: "instagram",
      content: "Transform your social media strategy with AI! 🚀",
      time: "Friday 7:00 PM",
      confidence: 0.87
    },
    {
      id: "2",
      platform: "tiktok",
      content: "POV: You just discovered AI automation...",
      time: "Friday 5:00 PM",
      confidence: 0.92
    },
    {
      id: "3",
      platform: "linkedin",
      content: "The future of marketing is here. AI-powered content...",
      time: "Tuesday 9:00 AM",
      confidence: 0.84
    },
    {
      id: "4",
      platform: "twitter",
      content: "Quick tip: Use AI to save 40% of your time...",
      time: "Friday 12:00 PM",
      confidence: 0.79
    }
  ];

  const handleGetRecommendation = async () => {
    setLoading(true);
    try {
      const result = await getOptimalSchedule(selectedPlatform === "all" ? "instagram" : selectedPlatform);
      setRecommendation(result);
      toast.success("Got optimal posting time!");
    } catch (error) {
      toast.error("Failed to get recommendation");
    } finally {
      setLoading(false);
    }
  };

  const handleAutoSchedule = () => {
    toast.success("All posts scheduled at optimal times!");
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "instagram":
        return <Instagram className="w-4 h-4 text-pink-600" />;
      case "tiktok":
        return (
          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12.53.02C13.84 0 15.14.01 16.44 0c.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
          </svg>
        );
      case "linkedin":
        return <Linkedin className="w-4 h-4 text-blue-600" />;
      case "twitter":
        return <Twitter className="w-4 h-4 text-blue-400" />;
      default:
        return null;
    }
  };

  const timeSlots = [
    { time: "6:00 AM", score: 45, label: "Low" },
    { time: "9:00 AM", score: 75, label: "Good" },
    { time: "12:00 PM", score: 85, label: "High" },
    { time: "3:00 PM", score: 65, label: "Medium" },
    { time: "5:00 PM", score: 92, label: "Peak" },
    { time: "7:00 PM", score: 88, label: "Peak" },
    { time: "9:00 PM", score: 55, label: "Medium" }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1>Smart Scheduler 📅</h1>
          <p className="text-muted-foreground">AI-optimized posting times for maximum engagement</p>
        </div>
        <Button onClick={handleAutoSchedule} size="lg" className="gap-2">
          <Sparkles className="w-4 h-4" />
          Auto-Schedule All
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar and Controls */}
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Select Date</CardTitle>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Platform Filter</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Platforms</SelectItem>
                  <SelectItem value="instagram">Instagram</SelectItem>
                  <SelectItem value="tiktok">TikTok</SelectItem>
                  <SelectItem value="linkedin">LinkedIn</SelectItem>
                  <SelectItem value="twitter">X (Twitter)</SelectItem>
                </SelectContent>
              </Select>

              <Button
                onClick={handleGetRecommendation}
                disabled={loading}
                className="w-full gap-2"
              >
                <Clock className="w-4 h-4" />
                Get Optimal Time
              </Button>

              {recommendation && (
                <div className="space-y-2 p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Recommended:</span>
                    <Badge>{recommendation.recommendedTime}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Confidence:</span>
                    <span className="text-sm">{Math.round(recommendation.confidence * 100)}%</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{recommendation.reasoning}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-2 space-y-4">
          {/* Engagement Heatmap */}
          <Card>
            <CardHeader>
              <CardTitle>Today's Engagement Forecast</CardTitle>
              <CardDescription>AI-predicted engagement levels by hour</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {timeSlots.map((slot, idx) => (
                  <div key={idx} className="flex items-center gap-3">
                    <span className="text-sm w-20">{slot.time}</span>
                    <div className="flex-1 bg-muted rounded-full h-6 overflow-hidden">
                      <div
                        className={`h-full flex items-center justify-end pr-2 text-xs transition-all ${
                          slot.score > 80
                            ? 'bg-green-500 text-white'
                            : slot.score > 60
                            ? 'bg-blue-500 text-white'
                            : slot.score > 40
                            ? 'bg-yellow-500'
                            : 'bg-gray-400'
                        }`}
                        style={{ width: `${slot.score}%` }}
                      >
                        {slot.score}%
                      </div>
                    </div>
                    <Badge variant={slot.score > 80 ? "default" : "secondary"} className="w-16 justify-center">
                      {slot.label}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Scheduled Posts */}
          <Card>
            <CardHeader>
              <CardTitle>Scheduled Posts</CardTitle>
              <CardDescription>Upcoming posts with AI-optimized timing</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {scheduledPosts.map((post) => (
                  <div
                    key={post.id}
                    className="flex items-start gap-3 p-4 border rounded-lg hover:bg-accent transition-colors"
                  >
                    <div className="mt-1">{getPlatformIcon(post.platform)}</div>
                    <div className="flex-1">
                      <p className="text-sm">{post.content}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Clock className="w-3 h-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">{post.time}</span>
                        <Badge variant="outline" className="text-xs">
                          {Math.round(post.confidence * 100)}% confidence
                        </Badge>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm">Edit</Button>
                      <Button variant="ghost" size="sm">Delete</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Weekly Overview */}
          <Card>
            <CardHeader>
              <CardTitle>This Week's Schedule</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, idx) => (
                  <div key={day} className="text-center">
                    <p className="text-xs text-muted-foreground mb-2">{day}</p>
                    <div className="space-y-1">
                      {idx === 1 && (
                        <div className="w-full h-6 bg-blue-500 rounded text-xs flex items-center justify-center text-white">
                          1
                        </div>
                      )}
                      {idx === 4 && (
                        <>
                          <div className="w-full h-6 bg-pink-500 rounded text-xs flex items-center justify-center text-white">
                            2
                          </div>
                          <div className="w-full h-6 bg-blue-400 rounded text-xs flex items-center justify-center text-white">
                            1
                          </div>
                        </>
                      )}
                      {(idx !== 1 && idx !== 4) && (
                        <div className="w-full h-6 bg-muted rounded"></div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
