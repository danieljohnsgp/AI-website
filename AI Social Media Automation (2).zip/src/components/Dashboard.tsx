import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { TrendingUp, Instagram, Linkedin, Twitter, Users, BarChart3, Clock, Zap } from "lucide-react";
import { platformStats, mockTrends, analyticsData } from "../lib/mockData";

interface DashboardProps {
  onNavigate: (view: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1>Welcome back! 👋</h1>
          <p className="text-muted-foreground">Here's what's happening with your social media today</p>
        </div>
        <Button onClick={() => onNavigate('creator')} size="lg" className="gap-2">
          <Zap className="w-4 h-4" />
          Create Post
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Time Saved</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{analyticsData.timeSavedPerWeek}</div>
            <p className="text-xs text-muted-foreground">per week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Consistency Rate</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{analyticsData.consistencyRate}</div>
            <p className="text-xs text-green-600">Above target (90%)</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Engagement</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{analyticsData.engagementIncrease}</div>
            <p className="text-xs text-green-600">vs last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Posts</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{analyticsData.totalPosts}</div>
            <p className="text-xs text-muted-foreground">all platforms</p>
          </CardContent>
        </Card>
      </div>

      {/* Platform Overview */}
      <div>
        <h2 className="mb-4">Platform Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader>
              <div className="flex items-center justify-between">
                <Instagram className="w-8 h-8 text-pink-600" />
                <Badge>Instagram</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Followers</span>
                <span>{platformStats.instagram.followers.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Avg Engagement</span>
                <span>{platformStats.instagram.avgEngagement}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Posts this week</span>
                <span>{platformStats.instagram.postsThisWeek}</span>
              </div>
              <div className="pt-2 border-t">
                <p className="text-xs text-muted-foreground">Best time: {platformStats.instagram.topPerformingTime}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader>
              <div className="flex items-center justify-between">
                <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12.53.02C13.84 0 15.14.01 16.44 0c.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
                </svg>
                <Badge>TikTok</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Followers</span>
                <span>{platformStats.tiktok.followers.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Avg Engagement</span>
                <span>{platformStats.tiktok.avgEngagement}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Posts this week</span>
                <span>{platformStats.tiktok.postsThisWeek}</span>
              </div>
              <div className="pt-2 border-t">
                <p className="text-xs text-muted-foreground">Best time: {platformStats.tiktok.topPerformingTime}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader>
              <div className="flex items-center justify-between">
                <Linkedin className="w-8 h-8 text-blue-600" />
                <Badge>LinkedIn</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Followers</span>
                <span>{platformStats.linkedin.followers.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Avg Engagement</span>
                <span>{platformStats.linkedin.avgEngagement}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Posts this week</span>
                <span>{platformStats.linkedin.postsThisWeek}</span>
              </div>
              <div className="pt-2 border-t">
                <p className="text-xs text-muted-foreground">Best time: {platformStats.linkedin.topPerformingTime}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader>
              <div className="flex items-center justify-between">
                <Twitter className="w-8 h-8 text-blue-400" />
                <Badge>X (Twitter)</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Followers</span>
                <span>{platformStats.twitter.followers.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Avg Engagement</span>
                <span>{platformStats.twitter.avgEngagement}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Posts this week</span>
                <span>{platformStats.twitter.postsThisWeek}</span>
              </div>
              <div className="pt-2 border-t">
                <p className="text-xs text-muted-foreground">Best time: {platformStats.twitter.topPerformingTime}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Trending Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Trending Now 🔥</CardTitle>
              <CardDescription>AI-curated trends for your industry</CardDescription>
            </div>
            <TrendingUp className="w-5 h-5 text-muted-foreground" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockTrends.map((trend) => (
              <div 
                key={trend.id} 
                className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent transition-colors cursor-pointer"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span>{trend.title}</span>
                    <Badge variant="secondary" className="text-xs">{trend.category}</Badge>
                  </div>
                  <div className="flex gap-1 flex-wrap">
                    {trend.hashtags.map((tag, idx) => (
                      <span key={idx} className="text-xs text-blue-600">{tag}</span>
                    ))}
                  </div>
                </div>
                <div className="text-sm text-muted-foreground">{trend.engagement} posts</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
