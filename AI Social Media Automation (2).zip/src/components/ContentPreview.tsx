import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Instagram, Linkedin, Twitter, Heart, MessageCircle, Share2, Bookmark, Send } from "lucide-react";

interface ContentPreviewProps {
  data?: {
    formatted: {
      instagram: string;
      tiktok: string;
      linkedin: string;
      twitter: string;
    };
  };
}

export function ContentPreview({ data }: ContentPreviewProps) {
  const mockContent = data?.formatted || {
    instagram: "Transform your social media strategy with AI! 🚀\n\nSave 40% of your time and 10x your engagement.\n\n#AI #SocialMedia #Marketing #Automation #ContentCreation\n\n✨ Follow for more tips!\n📲 Link in bio",
    tiktok: "Transform your social media strategy with AI! 🚀 Save 40% of your time and 10x your engagement... 🎵\n\n#AI #SocialMedia #Marketing #FYP #ForYou",
    linkedin: "Transform your social media strategy with AI! 🚀 Save 40% of your time and 10x your engagement.\n\nKey Insights:\n• AI-powered automation\n• Time-saving solutions\n• Data-driven results\n\n#AI #SocialMedia #Marketing",
    twitter: "Transform your social media strategy with AI! 🚀 Save 40% of your time and 10x your engagement.\n\n#AI #SocialMedia"
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1>Multi-Platform Preview 📱</h1>
        <p className="text-muted-foreground">See how your content looks on each platform</p>
      </div>

      <Tabs defaultValue="instagram" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="instagram" className="gap-2">
            <Instagram className="w-4 h-4" />
            Instagram
          </TabsTrigger>
          <TabsTrigger value="tiktok" className="gap-2">
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12.53.02C13.84 0 15.14.01 16.44 0c.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
            </svg>
            TikTok
          </TabsTrigger>
          <TabsTrigger value="linkedin" className="gap-2">
            <Linkedin className="w-4 h-4" />
            LinkedIn
          </TabsTrigger>
          <TabsTrigger value="twitter" className="gap-2">
            <Twitter className="w-4 h-4" />
            X
          </TabsTrigger>
        </TabsList>

        {/* Instagram Preview */}
        <TabsContent value="instagram" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Instagram Post Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden bg-white">
                  {/* Header */}
                  <div className="flex items-center gap-3 p-3 border-b">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500"></div>
                    <div>
                      <p className="text-sm">sparksocial_ai</p>
                      <p className="text-xs text-muted-foreground">2 hours ago</p>
                    </div>
                  </div>
                  
                  {/* Image placeholder */}
                  <div className="aspect-square bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center">
                    <Instagram className="w-16 h-16 text-muted-foreground" />
                  </div>
                  
                  {/* Actions */}
                  <div className="p-3 space-y-2">
                    <div className="flex items-center gap-4">
                      <Heart className="w-6 h-6" />
                      <MessageCircle className="w-6 h-6" />
                      <Send className="w-6 h-6" />
                      <Bookmark className="w-6 h-6 ml-auto" />
                    </div>
                    <p className="text-sm">1,234 likes</p>
                    <div className="text-sm">
                      <span>sparksocial_ai</span>
                      <p className="whitespace-pre-wrap mt-1">{mockContent.instagram}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Optimization Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm mb-2">Caption Length</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: '75%' }}></div>
                    </div>
                    <span className="text-sm text-muted-foreground">Optimal</span>
                  </div>
                </div>

                <div>
                  <p className="text-sm mb-2">Hashtags</p>
                  <Badge variant="secondary">5 tags - Recommended range</Badge>
                </div>

                <div>
                  <p className="text-sm mb-2">Engagement Score</p>
                  <div className="flex items-center gap-2">
                    <div className="text-2xl">8.5</div>
                    <span className="text-sm text-green-600">High potential</span>
                  </div>
                </div>

                <div>
                  <p className="text-sm mb-2">Best Posting Time</p>
                  <Badge>Friday 7:00 PM (87% confidence)</Badge>
                </div>

                <div className="pt-4 border-t space-y-2">
                  <p className="text-sm">AI Suggestions:</p>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Add emoji at the beginning for better visibility</li>
                    <li>Consider carousel post for higher engagement</li>
                    <li>Peak audience activity in 3 hours</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* TikTok Preview */}
        <TabsContent value="tiktok" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>TikTok Post Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden bg-black text-white max-w-sm mx-auto">
                  {/* TikTok style vertical video */}
                  <div className="aspect-[9/16] bg-gradient-to-br from-purple-900 to-pink-900 flex items-end p-4 relative">
                    <div className="absolute top-4 right-4 space-y-4">
                      <div className="flex flex-col items-center gap-1">
                        <div className="w-12 h-12 rounded-full bg-white/20"></div>
                        <Heart className="w-8 h-8" />
                        <span className="text-xs">12.5K</span>
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        <MessageCircle className="w-8 h-8" />
                        <span className="text-xs">890</span>
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        <Share2 className="w-8 h-8" />
                        <span className="text-xs">1.2K</span>
                      </div>
                    </div>
                    
                    <div className="flex-1">
                      <p className="text-sm">@sparksocial_ai</p>
                      <p className="text-sm mt-2 whitespace-pre-wrap">{mockContent.tiktok}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Optimization Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm mb-2">Caption Length</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: '65%' }}></div>
                    </div>
                    <span className="text-sm text-muted-foreground">Good</span>
                  </div>
                </div>

                <div>
                  <p className="text-sm mb-2">Hashtags</p>
                  <Badge variant="secondary">Includes #FYP and #ForYou</Badge>
                </div>

                <div>
                  <p className="text-sm mb-2">Virality Score</p>
                  <div className="flex items-center gap-2">
                    <div className="text-2xl">9.2</div>
                    <span className="text-sm text-green-600">Very high potential</span>
                  </div>
                </div>

                <div>
                  <p className="text-sm mb-2">Best Posting Time</p>
                  <Badge>Friday 5:00 PM (92% confidence)</Badge>
                </div>

                <div className="pt-4 border-t space-y-2">
                  <p className="text-sm">AI Suggestions:</p>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Add trending sound for 3x visibility</li>
                    <li>Hook viewers in first 3 seconds</li>
                    <li>Use text overlay for accessibility</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* LinkedIn Preview */}
        <TabsContent value="linkedin" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>LinkedIn Post Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden bg-white">
                  {/* Header */}
                  <div className="flex items-center gap-3 p-4 border-b">
                    <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center text-white">
                      SS
                    </div>
                    <div>
                      <p className="text-sm">SparkSocial AI</p>
                      <p className="text-xs text-muted-foreground">1,234 followers • 2h</p>
                    </div>
                  </div>
                  
                  {/* Content */}
                  <div className="p-4">
                    <p className="text-sm whitespace-pre-wrap">{mockContent.linkedin}</p>
                  </div>

                  {/* Image placeholder */}
                  <div className="aspect-video bg-gradient-to-br from-blue-100 to-cyan-100 flex items-center justify-center">
                    <Linkedin className="w-16 h-16 text-muted-foreground" />
                  </div>
                  
                  {/* Actions */}
                  <div className="p-4 border-t">
                    <div className="flex items-center justify-around text-sm text-muted-foreground">
                      <button className="flex items-center gap-2 hover:text-blue-600">
                        <Heart className="w-5 h-5" />
                        Like
                      </button>
                      <button className="flex items-center gap-2 hover:text-blue-600">
                        <MessageCircle className="w-5 h-5" />
                        Comment
                      </button>
                      <button className="flex items-center gap-2 hover:text-blue-600">
                        <Share2 className="w-5 h-5" />
                        Repost
                      </button>
                      <button className="flex items-center gap-2 hover:text-blue-600">
                        <Send className="w-5 h-5" />
                        Send
                      </button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Optimization Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm mb-2">Professional Tone Score</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div className="bg-blue-500 h-2 rounded-full" style={{ width: '90%' }}></div>
                    </div>
                    <span className="text-sm text-muted-foreground">Excellent</span>
                  </div>
                </div>

                <div>
                  <p className="text-sm mb-2">Hashtags</p>
                  <Badge variant="secondary">3 tags - Professional range</Badge>
                </div>

                <div>
                  <p className="text-sm mb-2">Engagement Score</p>
                  <div className="flex items-center gap-2">
                    <div className="text-2xl">7.8</div>
                    <span className="text-sm text-green-600">Good for B2B</span>
                  </div>
                </div>

                <div>
                  <p className="text-sm mb-2">Best Posting Time</p>
                  <Badge>Tuesday 9:00 AM (84% confidence)</Badge>
                </div>

                <div className="pt-4 border-t space-y-2">
                  <p className="text-sm">AI Suggestions:</p>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Add industry-specific insights</li>
                    <li>Include data or statistics</li>
                    <li>Tag relevant company pages</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Twitter/X Preview */}
        <TabsContent value="twitter" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>X (Twitter) Post Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden bg-white max-w-xl">
                  {/* Header */}
                  <div className="flex items-start gap-3 p-4">
                    <div className="w-12 h-12 rounded-full bg-blue-500"></div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm">SparkSocial AI</p>
                        <Badge variant="secondary" className="text-xs">@sparksocial_ai</Badge>
                        <span className="text-xs text-muted-foreground">• 2h</span>
                      </div>
                      <p className="text-sm mt-2 whitespace-pre-wrap">{mockContent.twitter}</p>
                      
                      {/* Image placeholder */}
                      <div className="mt-3 aspect-video bg-gradient-to-br from-sky-100 to-blue-100 rounded-lg flex items-center justify-center">
                        <Twitter className="w-12 h-12 text-muted-foreground" />
                      </div>
                      
                      {/* Stats */}
                      <div className="flex items-center gap-6 mt-3 text-muted-foreground text-sm">
                        <button className="flex items-center gap-2 hover:text-blue-500">
                          <MessageCircle className="w-4 h-4" />
                          <span>24</span>
                        </button>
                        <button className="flex items-center gap-2 hover:text-green-500">
                          <Share2 className="w-4 h-4" />
                          <span>12</span>
                        </button>
                        <button className="flex items-center gap-2 hover:text-red-500">
                          <Heart className="w-4 h-4" />
                          <span>89</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Optimization Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm mb-2">Character Count</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: '60%' }}></div>
                    </div>
                    <span className="text-sm text-muted-foreground">{mockContent.twitter.length}/280</span>
                  </div>
                </div>

                <div>
                  <p className="text-sm mb-2">Hashtags</p>
                  <Badge variant="secondary">2 tags - Optimal for X</Badge>
                </div>

                <div>
                  <p className="text-sm mb-2">Retweet Potential</p>
                  <div className="flex items-center gap-2">
                    <div className="text-2xl">7.3</div>
                    <span className="text-sm text-green-600">Good</span>
                  </div>
                </div>

                <div>
                  <p className="text-sm mb-2">Best Posting Time</p>
                  <Badge>Friday 12:00 PM (79% confidence)</Badge>
                </div>

                <div className="pt-4 border-t space-y-2">
                  <p className="text-sm">AI Suggestions:</p>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Keep it concise and punchy</li>
                    <li>Add a call-to-action</li>
                    <li>Consider thread format for more details</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
