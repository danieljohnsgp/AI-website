import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Instagram, Linkedin, Twitter, Check, ArrowRight, Loader2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface SocialConnectProps {
  onComplete: (connectedPlatforms: string[]) => void;
  onSkip: () => void;
}

interface Platform {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  description: string;
  followers?: string;
}

export function SocialConnect({ onComplete, onSkip }: SocialConnectProps) {
  const [connectedPlatforms, setConnectedPlatforms] = useState<string[]>([]);
  const [connectingPlatform, setConnectingPlatform] = useState<string | null>(null);

  const platforms: Platform[] = [
    {
      id: 'instagram',
      name: 'Instagram',
      icon: <Instagram className="w-8 h-8" />,
      color: 'from-purple-500 to-pink-500',
      description: 'Connect to share photos and stories',
      followers: '12.5K followers'
    },
    {
      id: 'tiktok',
      name: 'TikTok',
      icon: (
        <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12.53.02C13.84 0 15.14.01 16.44 0c.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
        </svg>
      ),
      color: 'from-black to-gray-700',
      description: 'Connect to share short-form videos',
      followers: '8.9K followers'
    },
    {
      id: 'linkedin',
      name: 'LinkedIn',
      icon: <Linkedin className="w-8 h-8" />,
      color: 'from-blue-600 to-blue-800',
      description: 'Connect to share professional content',
      followers: '3.2K connections'
    },
    {
      id: 'twitter',
      name: 'X (Twitter)',
      icon: <Twitter className="w-8 h-8" />,
      color: 'from-blue-400 to-blue-600',
      description: 'Connect to share quick updates',
      followers: '5.6K followers'
    }
  ];

  const handleConnect = async (platformId: string) => {
    setConnectingPlatform(platformId);
    
    // Simulate OAuth connection
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setConnectedPlatforms([...connectedPlatforms, platformId]);
    setConnectingPlatform(null);
    
    const platform = platforms.find(p => p.id === platformId);
    toast.success(`${platform?.name} connected successfully!`);
  };

  const handleDisconnect = (platformId: string) => {
    setConnectedPlatforms(connectedPlatforms.filter(id => id !== platformId));
    const platform = platforms.find(p => p.id === platformId);
    toast.info(`${platform?.name} disconnected`);
  };

  const handleContinue = () => {
    if (connectedPlatforms.length === 0) {
      toast.error('Please connect at least one platform to continue');
      return;
    }
    onComplete(connectedPlatforms);
  };

  const progress = (connectedPlatforms.length / platforms.length) * 100;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4">
      <div className="w-full max-w-4xl">
        <Card className="shadow-2xl">
          <CardHeader className="text-center space-y-2 pb-6">
            <div className="flex items-center justify-center gap-2 mb-2">
              <div className="text-4xl">🔗</div>
            </div>
            <CardTitle className="text-3xl">Connect Your Social Accounts</CardTitle>
            <CardDescription className="text-base">
              Link your social media platforms to start automating your content
            </CardDescription>
            
            <div className="pt-4">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-muted-foreground">
                  {connectedPlatforms.length} of {platforms.length} platforms connected
                </span>
                <span className="text-muted-foreground">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {platforms.map((platform) => {
                const isConnected = connectedPlatforms.includes(platform.id);
                const isConnecting = connectingPlatform === platform.id;

                return (
                  <Card 
                    key={platform.id}
                    className={`transition-all ${
                      isConnected 
                        ? 'border-green-500 bg-green-50 dark:bg-green-950/20' 
                        : 'hover:shadow-md'
                    }`}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className={`p-3 rounded-lg bg-gradient-to-br ${platform.color} text-white`}>
                          {platform.icon}
                        </div>
                        {isConnected && (
                          <Badge className="bg-green-500">
                            <Check className="w-3 h-3 mr-1" />
                            Connected
                          </Badge>
                        )}
                      </div>

                      <h3 className="text-lg mb-1">{platform.name}</h3>
                      <p className="text-sm text-muted-foreground mb-2">
                        {platform.description}
                      </p>
                      {isConnected && platform.followers && (
                        <p className="text-xs text-muted-foreground mb-3">
                          {platform.followers}
                        </p>
                      )}

                      {isConnected ? (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full"
                          onClick={() => handleDisconnect(platform.id)}
                        >
                          Disconnect
                        </Button>
                      ) : (
                        <Button
                          className="w-full"
                          onClick={() => handleConnect(platform.id)}
                          disabled={isConnecting}
                        >
                          {isConnecting ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Connecting...
                            </>
                          ) : (
                            'Connect'
                          )}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="flex items-center justify-between pt-4 border-t">
              <Button variant="ghost" onClick={onSkip}>
                Skip for now
              </Button>
              <Button 
                onClick={handleContinue}
                disabled={connectedPlatforms.length === 0}
                size="lg"
                className="gap-2"
              >
                Continue
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>

            <p className="text-xs text-center text-muted-foreground">
              Don't worry, you can connect more platforms later from your dashboard settings
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
