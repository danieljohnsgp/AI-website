// Mock API functions for SparkSocial

export interface GenerateRequest {
  prompt: string;
  brandTone: 'friendly' | 'professional' | 'casual' | 'formal';
}

export interface GenerateResponse {
  caption: string;
  hashtags: string[];
  contentTone: string;
}

export interface FormatRequest {
  caption: string;
  hashtags: string[];
}

export interface FormatResponse {
  instagram: string;
  tiktok: string;
  linkedin: string;
  twitter: string;
}

export interface ScheduleResponse {
  recommendedTime: string;
  confidence: number;
  reasoning: string;
}

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Mock AI caption generation
export async function generateContent(request: GenerateRequest): Promise<GenerateResponse> {
  await delay(1500); // Simulate API call

  const { prompt, brandTone } = request;
  
  // Simple mock responses based on tone
  const responses: Record<string, GenerateResponse> = {
    friendly: {
      caption: `Hey there! 👋 ${prompt} Let's make it happen together! We're all about making your life easier with AI-powered automation. Ready to level up? 🚀`,
      hashtags: ['#AI', '#SocialMedia', '#Marketing', '#Automation', '#ContentCreation'],
      contentTone: 'friendly'
    },
    professional: {
      caption: `${prompt} Our AI-driven platform enables marketing professionals to optimize their social media workflow, delivering measurable results and enhanced efficiency.`,
      hashtags: ['#DigitalMarketing', '#AI', '#BusinessGrowth', '#MarketingStrategy', '#Productivity'],
      contentTone: 'professional'
    },
    casual: {
      caption: `${prompt} Seriously, who has time for manual posting anymore? 😅 Let AI do the heavy lifting while you focus on what matters!`,
      hashtags: ['#SocialMediaTips', '#AITools', '#WorkSmarter', '#Marketing', '#TechLife'],
      contentTone: 'casual'
    },
    formal: {
      caption: `${prompt} We are committed to providing enterprise-grade social media management solutions powered by advanced artificial intelligence technology.`,
      hashtags: ['#Enterprise', '#AITechnology', '#DigitalTransformation', '#MarketingAutomation', '#B2B'],
      contentTone: 'formal'
    }
  };

  return responses[brandTone] || responses.friendly;
}

// Mock platform-specific formatting
export async function formatForPlatforms(request: FormatRequest): Promise<FormatResponse> {
  await delay(800);

  const { caption, hashtags } = request;
  const baseHashtags = hashtags.join(' ');

  return {
    instagram: `${caption}\n\n${baseHashtags}\n\n✨ Follow for more tips!\n📲 Link in bio`,
    tiktok: `${caption.substring(0, 150)}... 🎵\n\n${hashtags.slice(0, 3).join(' ')} #FYP #ForYou`,
    linkedin: `${caption}\n\nKey Insights:\n• AI-powered automation\n• Time-saving solutions\n• Data-driven results\n\n${hashtags.slice(0, 3).join(' ')}`,
    twitter: `${caption.substring(0, 240)}\n\n${hashtags.slice(0, 2).join(' ')}`
  };
}

// Mock smart scheduling
export async function getOptimalSchedule(platform: string): Promise<ScheduleResponse> {
  await delay(600);

  const schedules: Record<string, ScheduleResponse> = {
    instagram: {
      recommendedTime: 'Friday 7:00 PM',
      confidence: 0.87,
      reasoning: 'Highest engagement based on historical data. Your audience is most active during evening hours on weekdays.'
    },
    tiktok: {
      recommendedTime: 'Friday 5:00 PM',
      confidence: 0.92,
      reasoning: 'Peak activity time for your demographic. Early evening posts see 2.3x more engagement.'
    },
    linkedin: {
      recommendedTime: 'Tuesday 9:00 AM',
      confidence: 0.84,
      reasoning: 'Professional audiences engage most during morning work hours. Tuesday shows highest B2B engagement.'
    },
    twitter: {
      recommendedTime: 'Friday 12:00 PM',
      confidence: 0.79,
      reasoning: 'Lunch hour activity spike. Weekend anticipation drives higher interaction rates.'
    }
  };

  return schedules[platform] || schedules.instagram;
}

// Mock trend analysis
export async function analyzeTrends(category: string): Promise<any> {
  await delay(1000);
  
  return {
    trending: true,
    relevanceScore: 0.85,
    suggestedTopics: [
      'AI automation best practices',
      'Social media trends 2025',
      'Content creation tips',
      'Marketing efficiency hacks'
    ]
  };
}
