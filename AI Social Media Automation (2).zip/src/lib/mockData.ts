// Mock data for SparkSocial

export interface BrandProfile {
  name: string;
  tone: 'friendly' | 'professional' | 'casual' | 'formal';
  keywords: string[];
  category: string;
}

export interface Post {
  id: string;
  content: string;
  platform: 'instagram' | 'tiktok' | 'linkedin' | 'twitter';
  scheduledTime: string;
  status: 'draft' | 'scheduled' | 'published';
  engagement?: {
    likes: number;
    comments: number;
    shares: number;
  };
}

export interface Trend {
  id: string;
  title: string;
  category: string;
  engagement: string;
  hashtags: string[];
}

export const defaultBrandProfile: BrandProfile = {
  name: "SparkSocial",
  tone: "friendly",
  keywords: ["AI", "automation", "social media", "marketing"],
  category: "SaaS/Marketing"
};

export const mockTrends: Trend[] = [
  {
    id: "1",
    title: "AI Productivity Hacks",
    category: "Technology",
    engagement: "12.5K",
    hashtags: ["#AIProductivity", "#TechTips", "#Automation"]
  },
  {
    id: "2",
    title: "Behind the Scenes Content",
    category: "Marketing",
    engagement: "8.3K",
    hashtags: ["#BTS", "#Marketing", "#ContentCreation"]
  },
  {
    id: "3",
    title: "User Generated Content",
    category: "Social Media",
    engagement: "15.7K",
    hashtags: ["#UGC", "#Community", "#SocialMedia"]
  },
  {
    id: "4",
    title: "Quick Tips Format",
    category: "Education",
    engagement: "9.2K",
    hashtags: ["#QuickTips", "#LearnWithMe", "#Tutorial"]
  },
  {
    id: "5",
    title: "Collaboration Posts",
    category: "Business",
    engagement: "6.8K",
    hashtags: ["#Collab", "#Partnership", "#Business"]
  }
];

export const mockPosts: Post[] = [
  {
    id: "1",
    content: "Transform your social media strategy with AI! 🚀 Save 40% of your time this week.",
    platform: "instagram",
    scheduledTime: "2025-10-18T19:00:00",
    status: "scheduled",
    engagement: {
      likes: 0,
      comments: 0,
      shares: 0
    }
  },
  {
    id: "2",
    content: "The future of marketing is here. AI-powered content that converts. Let's talk about it.",
    platform: "linkedin",
    scheduledTime: "2025-10-19T09:00:00",
    status: "scheduled"
  },
  {
    id: "3",
    content: "POV: You just discovered AI automation for social media 🤯",
    platform: "tiktok",
    scheduledTime: "2025-10-18T17:00:00",
    status: "published",
    engagement: {
      likes: 1247,
      comments: 89,
      shares: 156
    }
  }
];

export const platformStats = {
  instagram: {
    followers: 12500,
    avgEngagement: "4.2%",
    postsThisWeek: 5,
    topPerformingTime: "7:00 PM"
  },
  tiktok: {
    followers: 8900,
    avgEngagement: "6.8%",
    postsThisWeek: 7,
    topPerformingTime: "5:00 PM"
  },
  linkedin: {
    followers: 3200,
    avgEngagement: "3.1%",
    postsThisWeek: 3,
    topPerformingTime: "9:00 AM"
  },
  twitter: {
    followers: 5600,
    avgEngagement: "2.9%",
    postsThisWeek: 8,
    topPerformingTime: "12:00 PM"
  }
};

export const analyticsData = {
  timeSavedPerWeek: "12 hours",
  consistencyRate: "94%",
  engagementIncrease: "+23%",
  totalPosts: 156,
  weeklyGrowth: "+8.5%"
};
