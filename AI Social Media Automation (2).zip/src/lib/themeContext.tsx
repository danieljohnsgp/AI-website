import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import type { PersonalizationSettings } from '../components/PersonalizationOnboarding';

interface ThemeContextType {
  settings: PersonalizationSettings;
  updateSettings: (settings: PersonalizationSettings) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<PersonalizationSettings>({
    theme: 'light',
    accentColor: 'blue',
    brandName: '',
    brandTone: 'friendly',
    industry: '',
    goals: ''
  });

  useEffect(() => {
    // Apply theme to document
    const root = document.documentElement;
    
    // Handle dark mode
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else if (settings.theme === 'light') {
      root.classList.remove('dark');
    } else {
      // Auto mode - use system preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }

    // Apply accent color
    root.setAttribute('data-accent', settings.accentColor);
    
    // Apply CSS variables for accent color
    const accentColors: Record<string, { light: string; dark: string; hsl: string }> = {
      blue: { light: '221.2 83.2% 53.3%', dark: '217.2 91.2% 59.8%', hsl: '221.2 83.2% 53.3%' },
      purple: { light: '262.1 83.3% 57.8%', dark: '263.4 70% 50.4%', hsl: '262.1 83.3% 57.8%' },
      pink: { light: '330.4 81.2% 60.4%', dark: '330.4 81.2% 60.4%', hsl: '330.4 81.2% 60.4%' },
      green: { light: '142.1 76.2% 36.3%', dark: '142.1 70.6% 45.3%', hsl: '142.1 76.2% 36.3%' },
      orange: { light: '24.6 95% 53.1%', dark: '20.5 90.2% 48.2%', hsl: '24.6 95% 53.1%' },
      red: { light: '0 84.2% 60.2%', dark: '0 72.2% 50.6%', hsl: '0 84.2% 60.2%' }
    };

    const color = accentColors[settings.accentColor] || accentColors.blue;
    root.style.setProperty('--primary', color.hsl);
  }, [settings]);

  const updateSettings = (newSettings: PersonalizationSettings) => {
    setSettings(newSettings);
  };

  return (
    <ThemeContext.Provider value={{ settings, updateSettings }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
