
  # AI Social Media Automation

  This is a code bundle for AI Social Media Automation. The original project is available at https://www.figma.com/design/Ozncqo26DahDpPaGlyvun8/AI-Social-Media-Automation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  